import os
from pathlib import Path

import joblib
import requests

from dialtag.dt_aux import csv_as_dicts, logger, store_csv_rows


def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def download_file(url, path):
    r = requests.get(url, stream=True)
    logger.info(f'Downloading: {path}.')
    with open(path, 'wb') as f:
        default_chunk_size = 1024
        for chunk in r.iter_content(chunk_size=default_chunk_size):
            if chunk:
                f.write(chunk)
                f.flush()


def request_file(url, path):
    ensure_dir(Path(path).parent)
    if not os.path.exists(path):
        download_file(url, path)
    else:
        logger.info(f'File exists: {path}.')


class StoredDialtagModel():

    def __init__(self, version ='dialtag_latest.csv'):
        logger.info(f'Requesting Dialtag model: {version}.')
        self.mlabel = ''
        self.mdir = os.path.join(Path.home(), 'dialtag_resources')
        self.mfiles = []
        gh = 'https://github.com/mdahllof/dialtag/raw/main/joblib/'
        request_file(gh + version, os.path.join(self.mdir, version))
        csvrows = csv_as_dicts(os.path.join(self.mdir, version))
        for itm in csvrows[0].items():
            logger.info(f'Model metadata {itm[0]}: {itm[1]}.')
        for f in [csvrows[0]['classifier'].strip(),
                  csvrows[0]['features'].strip()]:
            request_file(gh + f, os.path.join(self.mdir, f))
            self.mfiles.append(os.path.join(self.mdir, f))
        self.mlabel = csvrows[0]['label'].strip()

    def label(self):
        return self.mlabel

    def load_classifier(self):
        return joblib.load(open(self.mfiles[0], 'rb'))

    def features(self):
        return self.mfiles[1]

    def collect_predictions(self, test, res_csv):
        preds = self.load_classifier().predict(test[0])
        clabel = self.label()
        collres = []
        for j in range(len(preds)):
            collres.append(
                [test[1][j], preds[j], clabel, test[2][j], test[3][j]])
        res_csv2 = res_csv + clabel + '.csv'
        store_csv_rows(collres, res_csv2)
        return res_csv2






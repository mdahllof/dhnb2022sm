import csv
import logging
import os
import re

from sklearn.neural_network import MLPClassifier

logger = logging.getLogger('dialtag')
if logger.level == 0:
    logger.setLevel(logging.INFO)
log_handler = logging.StreamHandler()
red = '\x1b[38;5;196m'
# bold_red = '\x1b[31;1m' # https://stackoverflow.com/questions/384076/
bold_blue = '\x1b[34;1m'
reset = '\x1b[0m'
# fmtstr = bold_blue + '%(asctime)s %(levelname)s: %(message)s' + reset
fmtstr = bold_blue + '%(asctime)s DIALTAG: %(message)s' + reset
log_formatter = logging.Formatter(fmt=fmtstr, datefmt='%Y-%m-%d %H:%M:%S')
log_handler.setFormatter(log_formatter)
if not logger.hasHandlers():
    logger.addHandler(log_handler)


NREGEX = r'(först|två|andra|trett|fyr|fjärd|fem|sext|sjund|' + \
         r'sjutt|ått|nio|nitt|tio|elv|elft|tolf|tolv|fjor|tjug|fört).*'


def mlp(lays):
    return MLPClassifier(alpha=0.7, hidden_layer_sizes=lays, max_iter=400,
                         activation='relu', solver='adam', random_state=1)


def files_matching_re(ddir, regexp):
    sel_books = []
    for root, dirs, files in os.walk(ddir):
        for file in files:
            if re.match(regexp, file):
                sel_books.append({'file': os.path.join(ddir, file),
                                  'name': str(file)[:-4]})  # e.g. '.txt' rem.
    return sel_books


def parag_sequence_from_csv(toks):
    parags = [[[]]]
    wc, sc, pc = 0, 0, 0
    for i, pcs in enumerate(toks):
        pcs.append(-1)
        pcs[8] = i
        wc += 1
        if str(pcs[0]) == '1' and pcs[1] == '§':
            pc += 1
            sc += 1
            if parags[-1] != [[]]:
                parags.append([[]])
        elif str(pcs[0]) == '1':
            sc += 1
            if parags[-1][-1]:
                parags[-1].append([pcs])
            else:
                parags[-1][-1].append(pcs)
        else:
            parags[-1][-1].append(pcs)
    if parags[-1] and not parags[-1][-1]:
        parags[-1] = parags[-1][:-1]
    if not parags[-1]:
        del parags[-1]
    return parags


def section_division(parag):
    if len(parag) > 1 or parag[0][0][1] in ['–', '”', '…', '(']:
        return False
    tlist = []
    for token in parag[0]:
        if re.match(r'[\w\d].*', token[1]):
            tlist.append(token[1].lower())
    if len(tlist) == 0:
        return True
    if len(tlist) == 1:
        if tlist[0] in ['i', 'tre', 'sex', 'sju', 'vi']:
            return True
        if re.match(NREGEX, tlist[0]):
            return True
        if re.match(r'[\d].*', tlist[0]):
            return True
        if re.match(r'(ii|iv|vii|ix|xi).*', tlist[0]):
            return True
        if tlist[0] in ['v', 'x']:
            return True
    if len(tlist) == 2 and tlist[1] in ['kapitlet']:
        return True
    if 0 < len(tlist) < 3 and tlist[0] in ['dag', 'del', 'kapitel']:
        return True
    return False


def csv_as_lists(csvf):
    rows = []
    with open(csvf, newline='', encoding='utf8') as csvfile:
        for r in csv.reader(csvfile, delimiter=','):
            rows.append(r)
    return rows


def csv_list_from_0(csvf):
    rows = []
    with open(csvf, newline='', encoding='utf8') as csvfile:
        for r in csv.reader(csvfile, delimiter=','):
            rows.append(r[0])
    return rows


def csv_as_dicts(csvfile):
    with open(csvfile, newline='', encoding='utf8') as csvfile:
        csvreader = csv.DictReader(csvfile)
        return [bk for bk in csvreader]


def compare_csvs(csv1, csv2):
    rows = [csv_as_lists(csv1), csv_as_lists(csv2)]
    if len(rows[0]) != len(rows[1]):
        print('Different lengths {0} and {1}'.format(len(rows[0]),
                                                     len(rows[1])))
    else:
        for i, row in enumerate(rows[0]):
            if row != rows[1][i]:
                print('Different rows {0} and {1} at pos {2}'
                      .format(row, rows[1][i], i))


def store_csv_rows(rows, csvfile):
    with open(csvfile, mode='w', newline='', encoding='utf-8') as csvf:
        csvwriter = csv.writer(csvf, delimiter=',', quotechar='"',
                               quoting=csv.QUOTE_MINIMAL)
        for csvrow in rows:
            csvwriter.writerow(csvrow)


def store_csv_dict_rows(rows, fields, csvfile):
    with open(csvfile, 'w', newline='', encoding='utf8') as csvf:
        writer = csv.DictWriter(csvf, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for nr in rows:
            writer.writerow(nr)


def store_dict_inv(vdict, csvfile):
    """For storing a dictionary, frequency sorted."""
    rows = []
    for key in vdict.keys():
        row = {'key': key, 'val': vdict[key]}
        rows.append(row)
    rows.sort(key=lambda r: r['val'], reverse=True)
    with open(csvfile, 'w', newline='', encoding='utf8') as csvf:
        writer = csv.DictWriter(csvf, fieldnames=['key', 'val'],
                                extrasaction='ignore')
        writer.writeheader()
        for nr in rows:
            writer.writerow(nr)


def make_dir(newdir):
    if not os.path.exists(newdir):
        os.makedirs(newdir)
        logger.info(f'Made directory: {newdir}.')
    else:
        logger.info(f'Will use existing directory: {newdir}.')


def fractn_perm(charact, dict1, dict2):
    if charact in dict2 and dict2[charact] > 0:
        return round((1000 * dict1[charact]) / dict2[charact])
    return 0


def orthography_stats(parags):
    wc = 0
    diadict = {'”': 0, '’': 0, '–': 0}
    diadict_prg = {'”': 0, '’': 0, '–': 0}
    for parag in parags:
        if parag[0][0][1] in diadict:
            diadict_prg[parag[0][0][1]] += 1
        for sent in parag:
            wc += len(sent)
            for ls in sent:
                if ls[1] in diadict:
                    diadict[ls[1]] += 1
    valdict = {'style': 'unk'}
    if diadict['–'] > 0.005 * wc:
        valdict['style'] = 'dash'
    if diadict['”'] > 0.005 * wc and diadict['”'] > diadict['–']:
        valdict['style'] = 'quot'
    valdict['dq'] = round((1000 * diadict['”']) / wc)
    valdict['dqP'] = fractn_perm('”', diadict_prg, diadict)
    valdict['dash'] = round((1000 * diadict['–']) / wc)
    valdict['dashP'] = fractn_perm('–', diadict_prg, diadict)
    valdict['sq'] = round((1000 * diadict['’']) / wc)
    return valdict


def csv_data_dict(csvfiles, keyfield, filterfun=lambda r: True):
    corpusd = {}
    for csvfile in csvfiles:
        with open(csvfile, newline='', encoding='utf8') as csvf:
            csvreader = csv.DictReader(csvf)
            for row in csvreader:
                if filterfun(row):
                    corpusd[row[keyfield]] = row
    return corpusd


def predictions_dict(res_csv, cl):
    pdict = {}
    with open(res_csv, 'r', encoding='utf-8') as csvfile:
        for r in csv.reader(csvfile, delimiter=','):
            if r[2] == cl:
                pdict[r[3]] = r[1]
    return pdict
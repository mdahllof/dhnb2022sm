import csv
import os
import re
from random import randint

import stanza

from dialtag.dt_featconstr import combi_feats, dialtag_data_from_csv,\
    gen_feats_for_book, init_special, select_to_csv
from dialtag.dt_textunit import segm_book_dash, segm_book_quot
from dialtag.dt_aux import csv_as_lists, csv_list_from_0,\
    files_matching_re, logger, make_dir, orthography_stats,\
    parag_sequence_from_csv, predictions_dict
from dialtag.dt_output import dialtagged_to_csv, dialtagged_to_html,\
    tag_from_resdict
from dialtag.dt_stored_model import StoredDialtagModel


def tokenize(tln):
    tln = re.sub('[«»"“]', '”', tln)
    tln = re.sub('[‹›‘]', '’', tln)
    tln = re.sub('[—]', '–', tln)
    tln = re.sub('[_▷↵→•·♥]', '', tln)
    tln = re.sub(' +', ' ', tln)
    tln = re.sub(r'([.!?])[”] ([A-ZÅÄÖ])', r'\1 ”\n\n\2', tln)
    tln = re.sub(r'([.!?]) [”]([A-ZÅÄÖ])', r'\1\n\n” \2', tln)
    tln = re.sub(r'([–.,:!?;”])', r' \1 ', tln)
    tln = re.sub(' +', ' ', tln)
    tln = re.sub(r'([.!?]) ([A-ZÅÄÖ])', r'\1\n\n\2', tln)
    tln = re.sub(r' *\n\n *', r'\n\n', tln)
    tln = tln.strip()
    return tln


def word_to_list(w):
    if w.id == 1 and w.text == '§':
        return ['1', '§', '§', '§', '§', '§', '§', '§']
    return [w.id, w.text, w.lemma, w.upos, w.xpos,
            w.feats, w.head, w.deprel]


def add_tok(parsed_toks, word):
    wl = word_to_list(word)
    if not (parsed_toks and parsed_toks[-1][1] == '§' and wl[1] == '§'):
        parsed_toks.append(wl)


def save_tagged_on_csv(filep, parsed_toks):
    with open(filep, mode='w', newline='', encoding='utf-8') as csvf:
        csvwriter = csv.writer(csvf, delimiter=',', quotechar='"',
                               quoting=csv.QUOTE_MINIMAL)
        for csvrow in parsed_toks:
            csvwriter.writerow(csvrow)


def stanza_on_file(nlp, tfile):
    parsed_toks = []
    colltxt = ''
    with open(tfile, 'r', encoding='utf8') as ins:
        for line in ins:
            if colltxt == '':
                colltxt = line.strip()
            else:
                colltxt = colltxt + '\n\n§\n\n' + line.strip()
            if len(colltxt) > 250000:
                doc = nlp(tokenize(colltxt) + '\n\n§\n\n')
                for sentence in doc.sentences:
                    for word in sentence.words:
                        add_tok(parsed_toks, word)
                # print('Stanza tagging ' + str(len(colltxt)) +
                # ' char-chunk of ' + tfile)
                colltxt = ''
    doc = nlp(tokenize(colltxt))
    # print('Stanza tagging ' + str(len(colltxt)) +
    #      ' char-chunk (last one) of ' + tfile)
    for sentence in doc.sentences:
        for word in sentence.words:
            add_tok(parsed_toks, word)
    while parsed_toks[-1][1] == '§':
        del parsed_toks[-1]
    return parsed_toks


def dialtagged_to_manual_eval_csv(bk_structs, resdict, csvfile):
    eval_sample = []
    count = 0
    for bk_struct in bk_structs:
        tag_from_resdict(bk_struct, resdict)
        for tunit in bk_struct:
            if tunit.tp in ['quotparag', 'dashparag']:
                check_unit = False
                tlist = []
                for sent in tunit.cs:
                    for span in sent:
                        hp = ''
                        for ls in span.cs:
                            hp += ls[1] + ' '
                        status = ['-', '-']
                        if randint(0, 2500) == 1000:
                            count += 1
                            status = [str(count), 'T']
                            check_unit = True
                        tlist.append(status + [span.lb, hp, span.id])
                if check_unit:
                    eval_sample.extend(tlist)
                    eval_sample.append(['-', '-', '-', '-', '-'])
    with open(csvfile, mode='w', newline='', encoding='utf-8') as csvf:
        csvwriter = csv.writer(csvf, delimiter=',', quotechar='"',
                               quoting=csv.QUOTE_MINIMAL)
        for tu in eval_sample:
            csvwriter.writerow(tu)


def orthography_stats_books(books_tag, csvfile):
    metaflds = ['id', 'title']
    valflds = ['style', 'dq', 'dqP', 'dash', 'dashP', 'sq']
    tok_seqs, parag_seqs, dms = [], [], []
    for i in range(len(books_tag)):
        tok_seq = csv_as_lists(books_tag[i]['file'])
        parag_seq = parag_sequence_from_csv(tok_seq)
        dms.append(orthography_stats(parag_seq))
    with open(csvfile, mode='w', newline='', encoding='utf-8') as csvf:
        csvwriter = csv.writer(csvf, delimiter=',', quotechar='"',
                               quoting=csv.QUOTE_MINIMAL)
        csvwriter.writerow(metaflds + valflds)
        for i, dm in enumerate(dms):
            book_vals = [str(dm[k]) for k in valflds]
            csvwriter.writerow(['A' + str(i),
                                books_tag[i]['name']] + book_vals)
    return dms


def stanza_tag_books(books, taggeddir, retag=False):
    nlp = stanza.Pipeline('sv', tokenize_pretokenized=True,
                          processors='tokenize, pos, lemma, depparse')
    for i in range(len(books)):
        csvf = os.path.join(taggeddir, books[i]['name'] + '.csv')
        if retag or not os.path.exists(csvf):
            logger.info(f'Tagging (Stanza): {books[i]["file"]}.')
            save_tagged_on_csv(csvf, stanza_on_file(nlp, books[i]['file']))
        else:
            logger.info(f'Using existing Stanza file for: {books[i]["file"]}.')


def gen_feats_from_files(bk_prgs, fs_init, fs_main):
    doc_labels, doc_feats, doc_uids = [], [], []
    for i, prgs in enumerate(bk_prgs):
        # md = ['A' + str(i), 'T' + str(i)]
        dl, df, du = gen_feats_for_book(prgs, fs_init, fs_main)
        doc_labels.extend(dl)
        doc_feats.extend(df)
        doc_uids.extend(du)
    return doc_labels, doc_feats, doc_uids


def select_by_style(books_all, dms, style):
    books = []
    for i in range(len(books_all)):
        if dms[i]['style'] == style:
            books.append(books_all[i])
    return books


def tag_qi_nf_from_quotmks(books, tagdir, cdir, hdir):
    for i in range(len(books)):
        taggedcsv = os.path.join(tagdir, books[i]['name'] + '.csv')
        tok_seq = csv_as_lists(taggedcsv)
        parag_seq = parag_sequence_from_csv(tok_seq)
        bk_struct = segm_book_quot(parag_seq, 'T' + str(i))
        dl, _, du = gen_feats_for_book(bk_struct, init_special, combi_feats)
        resdict = {}
        for j, uid in enumerate(du):
            resdict[uid[1]] = dl[j]
        dialtagged_to_csv(bk_struct, books[i]['name'], tok_seq, resdict, cdir)
        dialtagged_to_html(bk_struct, i, books[i]['name'], resdict, hdir)


def classify_qi_nf(dialtag_model, books, wdir, tagdir, cdir, hdir):
    tok_seqs, parag_seqs, bk_structs = [], [], []
    for i in range(len(books)):
        csvf = os.path.join(tagdir, books[i]['name'] + '.csv')
        tok_seqs.append(csv_as_lists(csvf))
        parag_seqs.append(parag_sequence_from_csv(tok_seqs[-1]))
        bk_structs.append(segm_book_dash(parag_seqs[-1], 'T' + str(i)))
    te_data = gen_feats_from_files(bk_structs, init_special, combi_feats)
    feats_sel = csv_list_from_0(dialtag_model.features())
    select_to_csv(te_data, feats_sel, wdir + 'qfeatste.csv')
    test = dialtag_data_from_csv(wdir + 'qfeatste.csv', 1000000)  # i.e. all
    res_csv2 = dialtag_model.collect_predictions(test, wdir + 'qpred')
    logger.info(f'Generating CSV and HTML.')
    resdict = predictions_dict(res_csv2, dialtag_model.label())
    dialtagged_to_manual_eval_csv(bk_structs, resdict, wdir + 'manu.csv')
    for i in range(len(books)):
        dialtagged_to_csv(bk_structs[i], books[i]['name'], tok_seqs[i],
                          resdict, cdir)
        dialtagged_to_html(bk_structs[i], i, books[i]['name'], resdict, hdir)


def tag_qi_nf(tdir, wdir):
    """
    The main pipeline for classification of quoted inset and
    narrative frame material.
    Parameters:
    tdir: directory for input txt files
    wdir: directory for output files (put in different subdirectories)
    """
    sdr = [wdir + 'stanza/', wdir + 'dialtag/', wdir + 'html/']
    for directory in sdr:
        make_dir(directory)
    # Use Stanza to tag the book files that were supplied.
    books_txt = files_matching_re(tdir, '.*[\\.]txt')
    stanza_tag_books(books_txt, sdr[0])
    books_tag = files_matching_re(sdr[0], '.*[\\.]csv')
    # Compute some orthography statistics from the Stanza csvs.
    # Decides whether they are of 'dash' or 'quot' orthography.
    # See file wdir + 'dialogue_stats.csv'.
    dms = orthography_stats_books(books_tag, wdir + 'dialogue_stats.csv')
    # Use classifier to tag dash-orthography works.
    books_dash = select_by_style(books_tag, dms, 'dash')
    dialtag_model = StoredDialtagModel()
    classify_qi_nf(dialtag_model, books_dash, wdir, sdr[0], sdr[1], sdr[2])
    # Use rule-based module to tag quotation-mark-orthography works.
    books_quot = select_by_style(books_tag, dms, 'quot')
    tag_qi_nf_from_quotmks(books_quot, sdr[0], sdr[1], sdr[2])




from dialtag.dt_aux import section_division


class Textunit:
    def __init__(self, tp, cs, lb, idfr):
        self.tp = tp
        self.cs = cs
        self.lb = lb
        self.id = idfr
        self.narrfeats = None
        self.ev = ''

    def __str__(self):
        return str(self.tp) + str(self.cs) + str(self.lb) + str(self.id)


def correct_quote_parag(prg):
    quots = 0
    if section_division(prg):
        return 'division'
    for sent in prg:
        for tok in sent:
            if tok[1] == '”':
                quots += 1
    if quots > 1 and quots % 2 == 0:
        return 'corr'
    if quots > 1:
        return 'incorrquot'
    return 'narrparag'


def append_last_nonempty(divs, wrd):
    while len(divs[-1].cs) == 0 and len(divs) > 1:
        divs = divs[:-1]
    divs[-1].cs.append(wrd)
    return divs


def rem_empty(divs, pid):
    divs_ne = []
    segmnr = 0
    for segm in divs:
        if len(segm.cs) > 0:
            segm.id = pid + '_' + str(segmnr)
            segmnr += 1
            divs_ne.append(segm)
    return divs_ne


def segm_sents_quot(parag, pid):
    divp = []
    in_quot = 'nonquote'
    divs = []
    for p in range(len(parag)):
        divs.append(Textunit('segm', [], in_quot, ''))
        for i in range(len(parag[p])):
            if parag[p][i][1] in [',', '?', '!', '–', '…', ':']:
                divs = append_last_nonempty(divs, parag[p][i])
                divs.append(Textunit('segm', [], in_quot, ''))
            elif parag[p][i][1] in ['”'] and in_quot == 'nonquote':
                in_quot = 'inquote'
                divs.append(Textunit('segm', [parag[p][i]], in_quot, ''))
            elif parag[p][i][1] in ['”'] and in_quot == 'inquote':
                divs = append_last_nonempty(divs, parag[p][i])
                # print([w[1] + '/' + w[4] for w in divs[-1].cs], 'avs')
                in_quot = 'nonquote'
                divs.append(Textunit('segm', [], in_quot, ''))
            else:
                divs[-1].cs.append(parag[p][i])
        divsne = rem_empty(divs, pid + '_' + str(p))
        # for divs in divsne:
            # print([w[1] for w in divs.cs], divs.lb)
        divp.append(divsne)
        divs = []
    ptype = 'quotparag'
    if divp[0][0].lb != 'inquote':
        ptype = 'niquotparag'
    return Textunit(ptype, divp, 'na', pid)


def segment_sents_dash(parag, pid):
    divp = []
    divs = []
    for si in range(len(parag)):
        divs.append(Textunit('segm', [], 'na', ''))
        for ti in range(len(parag[si])):
            if parag[si][ti][1] in [',', '?', '!', '…', ':']:
                divs = append_last_nonempty(divs, parag[si][ti])
                divs.append(Textunit('segm', [], 'na', ''))
            else:
                divs[-1].cs.append(parag[si][ti])
        divsne = rem_empty(divs, pid + '_' + str(si))
        divp.append(divsne)
        divs = []
    return Textunit('dashparag', divp, 'na', pid)


def segm_book_quot(prgs, bkid):
    psegms = [None for _ in prgs]
    for i in range(len(prgs)):
        segmid = bkid + '_' + str(i)
        status = correct_quote_parag(prgs[i])
        if status == 'corr':
            psegms[i] = segm_sents_quot(prgs[i], segmid)
        elif section_division(prgs[i]):
            psegms[i] = Textunit('division', prgs[i], 'na', segmid)
        else:
            psegms[i] = Textunit(status, prgs[i], 'na', segmid)
    return psegms


def segm_book_dash(prgs, bkid):
    psegms = [None for _ in prgs]
    for i in range(len(prgs)):
        segmid = bkid + '_' + str(i)
        if prgs[i][0][0][1] == '–':
            psegms[i] = segment_sents_dash(prgs[i], segmid)
        elif section_division(prgs[i]):
            psegms[i] = Textunit('division', prgs[i], 'na', segmid)
        else:
            psegms[i] = Textunit('narrparag', prgs[i], 'na', segmid)
    return psegms



import csv


def tag_csv_tokens(sclass, lst, tok_seq):
    for ls in lst:
        tok_seq[int(ls[8])].append(sclass)


def copy_tag_parags(tunit, tok_seq):
    if tunit.tp in ['quotparag', 'dashparag']:
        for sent in tunit.cs:
            for span in sent:
                tag_csv_tokens(span.lb, span.cs, tok_seq)
    elif tunit.tp == 'niquotparag':
        for sent in tunit.cs:
            for span in sent:
                tag_csv_tokens('niq', span.cs, tok_seq)
    elif tunit.tp == 'division':
        for sent in tunit.cs:
            tag_csv_tokens('divis', sent, tok_seq)
    else:
        for sent in tunit.cs:
            tag_csv_tokens('nondial', sent, tok_seq)


def tag_from_resdict(bk_struct, resdict):
    for tunit in bk_struct:
        if tunit.tp in ['dashparag']:
            for sent in tunit.cs:
                for span in sent:
                    span.lb = resdict.get(span.id, 'nonc')
        elif tunit.tp in ['quotparag']:
            for sent in tunit.cs:
                for span in sent:
                    span.lb = resdict.get(span.id, 'nonc')


def dialtagged_to_csv(bk_struct, bk_name, tok_seq, resdict, hdir):
    tag_from_resdict(bk_struct, resdict)
    for psegm in bk_struct:
        copy_tag_parags(psegm, tok_seq)
    csvfile = hdir + bk_name + '_dial.csv'
    with open(csvfile, mode='w', newline='', encoding='utf-8') as csvf:
        csvwriter = csv.writer(csvf, delimiter=',', quotechar='"',
                               quoting=csv.QUOTE_MINIMAL)
        csvwriter.writerows(tok_seq)


def dialtagged_to_html(bk_struct, i, bk_name, resdict, hdir):
    book = {'id': 'B' + str(i), 'title': bk_name, 'author1': 'A' + str(i)}
    tag_from_resdict(bk_struct, resdict)
    hlines = preamb(book['title'] + ' &bull; ' + book['author1'])
    for psegm in bk_struct:
        hlines.extend(html_parags(psegm))
    hlines.extend(['</body>', '</html>'])
    with open(hdir + bk_name + '.html',
              mode='w', newline=None, encoding='utf-8') as hf:
        for pline in hlines:
            hf.write(pline + '\n')


def span_class_elems(hp, sclass, lst):
    spant = '<span class="' + sclass + '">'
    for ls in lst:
        hp.append(spant + ls[1] + ' </span>')


def html_parags(tunit):
    hp = ['<p>']
    if tunit.tp in ['quotparag', 'dashparag']:
        for sent in tunit.cs:
            for span in sent:
                span_class_elems(hp, span.lb, span.cs)
                hp.append('<span class="delim">|' + span.id + '|</span>')
    elif tunit.tp == 'niquotparag':
        for sent in tunit.cs:
            for span in sent:
                span_class_elems(hp, 'niq', span.cs)
    elif tunit.tp == 'division':
        for sent in tunit.cs:
            span_class_elems(hp, 'divis', sent)
    else:
        for sent in tunit.cs:
            span_class_elems(hp, 'nondial', sent)
    hp.append('</p>')
    return hp


def csv_class_elems(hp, sclass, lst):
    for ls in lst:
        hp.add_row(ls + [sclass])


def markup_csv(tunit, rows):
    if tunit.tp in ['quotparag', 'dashparag']:
        for sent in tunit.cs:
            for span in sent:
                csv_class_elems(rows, span.lb, span.cs)
    elif tunit.tp == 'niquotparag':
        for sent in tunit.cs:
            for span in sent:
                csv_class_elems(rows, 'niq', span.cs)
    elif tunit.tp == 'division':
        for sent in tunit.cs:
            csv_class_elems(rows, 'divis', sent)
    else:
        for sent in tunit.cs:
            csv_class_elems(rows, 'nondial', sent)


def preamb(tit):
    return ['<!DOCTYPE html>',
            '<html lang="sv" xmlns="http://www.w3.org/1999/xhtml">',
            '<head>', '<title>' + tit + '</title>',
            '<meta http-equiv="Content-Type" content="text/html; '
            'charset=utf-8" />',
            '<style type="text/css">',
            'td, th {border: 1px solid black;}',
            'span.nondial {background-color:#C0C0C0;}',
            'span.divis {font-size: 18px; font-weight: bold; color:#8B0000;}',
            'span.na {color:#000000; background-color:#FFFFCC;}',
            'span.nonc {color:#000000; background-color:#FFFFCC;}',
            'span.nonquote {background-color:#B0C4DE;}',
            'span.inquote {background-color:#FFB6C1;}',
            'span.dashinit {background-color:#98FB98;}',
            'span.delim {font-size: 7px; color:#FF4500;}',
            'span.niq {background-color:#FFF0F5;}',
            'span.truec {color:#000000; background-color:#90EE90;}',
            'span.falsec {color:#000000; background-color:#FFA07A;}',
            'span.pn {color:#006400;}',
            'span.dct {font-size: 9px; color:#9400D3;}',
            'span.ev {font-size: 9px; border-style: solid; ',
            '         border-color: #9ACD32;}',
            'span.relp {background-color:#C0C0C0;}',
            'span.diainit {color:#0000CD;}',
            'span.diaev {color:#0000CD; background-color:#FFFACD;}',
            'span.inq {font-weight: bold; color:#008000;' +
            ' background-color:#C0C0C0;}',
            'span.inqsec {font-weight: bold; color:#000000;' +
            ' background-color:#FF6347;}',
            'span.amb {color:#000000; background-color:#FFD700;}',
            'table {border-collapse: collapse;}',
            '</style>', '</head>', '<body>']
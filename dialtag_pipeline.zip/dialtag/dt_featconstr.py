import csv
import re

import pandas as pd

from dialtag.dt_aux import store_csv_rows
from dialtag.dt_output import dialtagged_to_html

SPECFEATS = ['NRPRT', 'NRPRS', 'NRp1', 'NRp2', 'NRp3',
             'initsegm',
             'S0PRT', 'S0PRS', 'S0p1', 'S0p2', 'S0p3',
             'W0PRS', 'W0PRT',
             'PRS', 'PRT', 'p1', 'p2', 'p3']

possprons = {'min': 'p1', 'vår': 'p1', 'din': 'p2', 'er': 'p2',
             'hans': 'p3', 'hennes': 'p3', 'deras': 'p3'}

persprons = {'jag': 'p1', 'vi': 'p1', 'du': 'p2', 'ni': 'p2',
             'han': 'p3', 'hon': 'p3', 'de': 'p3'}  # 'mig' is 'jag' lemma


def init_special(fset, prefix, tknlist):
    fset = fset.copy()
    wsegm = list(filter(lambda wrd: wrd[1] not in ['”', '–'], tknlist))
    for w in wsegm:
        if re.match('VB[|]PRS.*', w[4]):
            fset.add(prefix + 'PRS')
        if re.match('VB[|]PRT.*', w[4]):
            fset.add(prefix + 'PRT')
        if re.match('PS.*', w[4]) and w[2] in possprons:
            fset.add(prefix + possprons[w[2]])
        if re.match('PN.*', w[4]) and w[2] in persprons:
            fset.add(prefix + persprons[w[2]])
    return fset


def no_feats(fset, prefix, tknlist):
    return fset


def spec_feats(fset, tknlist):
    fset = fset.copy()
    wsegm = list(filter(lambda wrd: wrd[1] not in ['”', '–'], tknlist))
    if len(wsegm) < 0:
        if re.match('VB[|]PRS.*', wsegm[0][4]):
            fset.add('W0PRS')
        elif re.match('VB[|]PRT.*', wsegm[0][4]):
            fset.add('W0PRT')
        for w in wsegm:
            if re.match('VB[|]PRS.*', w[4]):
                fset.add('PRS')
            if re.match('VB[|]PRT.*', w[4]):
                fset.add('PRT')
            if re.match('PS.*', w[4]) and w[2] in possprons:
                print(possprons[w[2]])
                fset.add(persprons[w[2]])
            if re.match('PN.*', w[4]) and w[2] in persprons:
                fset.add(persprons[w[2]])
    return fset


def dynam_feats(fset, tknlist):
    fset = fset.copy()
    wsegm = list(filter(lambda wrd: wrd[1] not in ['”', '–'], tknlist))
    if len(wsegm) > 0:
        if not re.match('PM[|].*', wsegm[0][4]):
            fset.add('0_' + wsegm[0][1])  # forms
        fset.add('0_' + wsegm[0][4].lower())  # pos
        for w in range(1, len(wsegm)):
            if not re.match('PM[|].*', wsegm[w][4]):
                fset.add(wsegm[w][1].lower())  # forms
        for i in range(len(wsegm) - 1):  # tag bigrams
            fset.add((wsegm[i][4] + '_' + wsegm[i + 1][4]).lower())
    return fset


def combi_feats(fset, tknlist):
    fset1 = spec_feats(fset, tknlist)
    # print('fset1 = ', fset1)
    fset2 = dynam_feats(fset1, tknlist)
    return fset2


def toklist(parag):
    wl = []
    for s in parag:
        wl.extend(s)
    return wl


def segm_ln(tknlist):
    return len(list(filter(lambda wrd: wrd[1] not in ['”', '–'], tknlist)))


def tagged_to_html(book, prgs, dl, du):
    resdict = {}
    for i, uid in enumerate(du):
        resdict[uid[1]] = dl[i]
    dialtagged_to_html(prgs, 0, book['id'], resdict, 'c:/popres/htmlquot/')


def gen_feats_for_book(prgs, fs_init, fs_main):
    doc_labels, doc_feats, doc_uids = [], [], []
    narrfeats = set()
    for p in range(len(prgs)):
        if prgs[p].tp == 'quotparag':  # prgs[p].cs[0][0].lb == 'inquote':
            feats_init_segm = fs_init(narrfeats, 'S0', prgs[p].cs[0][0].cs)
            for i in range(len(prgs[p].cs)):  # sentences
                for j in range(len(prgs[p].cs[i])):  # segments
                    feats = fs_main(feats_init_segm, prgs[p].cs[i][j].cs)
                    if i + j == 0:  # first_segm special
                        feats.add('initsegm')
                    doc_feats.append(feats)
                    doc_labels.append(prgs[p].cs[i][j].lb)
                    sl = str(segm_ln(prgs[p].cs[i][j].cs))
                    doc_uids.append([sl, prgs[p].cs[i][j].id])
        elif prgs[p].tp == 'dashparag':
            feats_init_segm = fs_init(narrfeats, 'S0', prgs[p].cs[0][0].cs)
            for i in range(len(prgs[p].cs)):  # sentences
                for j in range(len(prgs[p].cs[i])):  # segments
                    doc_labels.append(prgs[p].cs[i][j].lb)
                    feats = fs_main(feats_init_segm, prgs[p].cs[i][j].cs)
                    if i + j == 0:  # first_segm special
                        feats.add('initsegm')
                    doc_feats.append(feats)
                    sl = str(segm_ln(prgs[p].cs[i][j].cs))
                    doc_uids.append([sl, prgs[p].cs[i][j].id])
        elif prgs[p].tp == 'narrparag':
            tknlist = toklist(prgs[p].cs)
            narrfeats = fs_init(set(), 'NR', tknlist)
    return doc_labels, doc_feats, doc_uids


def select_to_csv(table, selected, feats_csv):
    labels, feats, uids = table[0], table[1], table[2]
    feat_vectors = []
    for i in range(len(labels)):
        featl = []
        for key in selected:
            if key in feats[i]:
                featl.append('1')
            else:
                featl.append('0')
        feat_vectors.append([labels[i]] + uids[i] + featl)
    store_csv_rows(feat_vectors, feats_csv)


def load_book_subset(csvfile, ss_labels):
    bk_subset = []
    with open(csvfile, newline='', encoding='utf8') as csvfile:
        csvreader = csv.DictReader(csvfile)
        for e in csvreader:
            if e['set'] in ss_labels:
                bk_subset.append(e)
    return bk_subset


def dialtag_data_from_csv(feats_csv, n_feats):
    datafr = pd.read_csv(feats_csv, header=None, encoding='utf-8',
                         low_memory=False)
    vectors = [r[3: n_feats + 3] for r in datafr.values.tolist()]
    actual_labels = datafr[0].tolist()
    slengths = datafr[1].tolist()
    uids = datafr[2].tolist()
    return vectors, actual_labels, uids, slengths


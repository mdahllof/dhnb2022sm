import os

import stanza

from dialtag.dt_aux import make_dir
from dialtag.dt_stored_model import request_file
from dialtag.dt_pipeline import tag_qi_nf


sample_texts = ['lbpf11729834.txt', 'lbpf2623648.txt',
                'lbpf262942.txt', 'lbpf8203284.txt']


def download_sample_texts(tdir):
    make_dir(tdir)
    gh = 'https://github.com/mdahllof/dialtag/raw/main/sampletext/'
    for st in sample_texts:
        request_file(gh + st, os.path.join(tdir, st))


if __name__ == '__main__':
    # put input files in a directory, plain .txt files.
    txtdir = 'C:/popres/txtsample6/' # (for instance)
    # Or, optionally, use these (from https://github.com/mdahllof/lbpf)
    download_sample_texts(txtdir)
    # download the stanza tagger
    stanza.download('sv')
    # for output: tagged .html (dialogue) and .csv (stanza)
    resdir = 'C:/popres/txttmp22/'
    tag_qi_nf(txtdir, resdir)